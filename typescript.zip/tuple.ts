let role:[string,string,number,boolean]=["mayur","jadhav",45,false]
console.warn(role)



// let trial:[string,string,number,boolean]=["mayur",4,false,32] 
// it will give error if the index described with 
// the  same data type is not assigned.

let tria2:any[]=[true,false,"mayur",34,"jadhav"]
console.log(tria2)


