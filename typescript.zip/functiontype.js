"use strict";
exports.__esModule = true;
exports.addition = void 0;
var aa = "hello world";
var bb = 4;
function addition(code) {
    return code + aa;
}
exports.addition = addition;
console.warn(addition("hello world"));
