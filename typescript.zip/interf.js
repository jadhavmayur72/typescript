var changeInSize = {
    height: 25,
    width: 35,
    color: "yellow",
    per: false
};
console.log(changeInSize);
