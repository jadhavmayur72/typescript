var a = 465;
var b = "hello world";
var c = false;
var d;
console.warn(a, b, c, d);
var carYear = 2015;
var carModel = "Swift";
var carType = "sports";
var absAvail = true;
var car = {
    year: carYear,
    type: carType,
    model: carModel,
    abs: absAvail
};
console.log(car);
