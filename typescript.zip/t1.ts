function add(a: number, b: number) {
  return a + b;
}
console.log(add(4, 5));
