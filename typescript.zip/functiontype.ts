
let aa="hello world"
let bb=4
export function addition(code:string):string | number{
    return code +aa
}
console.warn(addition("hello world"))