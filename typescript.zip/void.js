// void is nothing but blank
// if a function dosent give any about or dosent 
// return andy thing then it is said to be void
function check2() {
    console.warn("hellllo");
}
// it not returning anything so it is void function 
check2();
var today;
function checking() {
    return today = new Date;
}
console.log(checking());
